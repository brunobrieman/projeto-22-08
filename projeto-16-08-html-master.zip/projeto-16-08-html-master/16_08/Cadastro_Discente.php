<?php
include("cabecalho.php");
?>



<div class="container_cadastro">
<center><h1 class="Titulo_cadastro_discente">Cadastro Discente<h1></center>
  <form action="#" class="form-contact" method="post" tabindex="1">

    <input type="text" class="form-contact-input" name="nome" placeholder="Nome Completo" required />

    <input type="email" class="form-contact-input" name="curso" placeholder="Curso" required />

    <input type="number" class="form-contact-input" name="mat" placeholder="Matricula" required />

    <input type="tel" class="form-contact-input" name="nome_resp" placeholder="Nome Responsaveis" />

     <input type="tel" class="form-contact-input" name="tel_resp" placeholder="Telefone Responsaveis" />

     

    

    <button type="submit" class="form-contact botao_cadastro">Enviar</button>
    <a href="Cadastro_Externo.php"><h1 class="Cadastro_exerno_link">Cadastrar Externo</h1></a>
  </form>
</div>

